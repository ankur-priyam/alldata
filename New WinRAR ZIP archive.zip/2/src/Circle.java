import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Circle extends Shapes {

	public static void main(String[] args) throws IOException {
		Circle obj=new Circle();
		obj.input();
		obj.area();

	}

	@Override
	void input() throws IOException {
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter radius");
		radius=Double.parseDouble(in.readLine());
		
	}

	@Override
	void area() {
		System.out.println("Area= " + (Math.PI*(radius*radius)));
	}

}
