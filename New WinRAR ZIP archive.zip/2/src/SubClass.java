
public class SubClass extends InheritanceApplication {
	
	
	
	public void output()
	{
		String name2="new student";
		System.out.println(name2);
	}
	public void display() {
		roll_no=1;
		name="Astha";
		percent=39.33;
		System.out.println(name + " " + percent);
	}
	public static void main(String[] args) {
		SubClass obj=new SubClass();
		obj.output();
		obj.display();
				
		}

	}


