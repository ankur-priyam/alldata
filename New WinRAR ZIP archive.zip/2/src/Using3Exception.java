import java.util.Scanner;


public class Using3Exception {
	static int acc_no=44591011;
	static int balance=5000;
	static int pin=1234;
	class InsufficientFundsException extends Exception
	{
		public InsufficientFundsException()
		{
			super("not enough balance");
		}
	}

	class InvalidAccountException extends Exception
	{
		public InvalidAccountException()
		{
			
		super("invalid acc no");
		}
	}
	class InvalidPasswordException extends Exception
	{

		public InvalidPasswordException()
		{
			super("wrong pin");
	}
}
static void throwingException()
{
	Scanner in=new Scanner(System.in);
	try
	{
		System.out.println("enter account no");
		int acc=in.nextInt();
		if(acc!=acc_no)
			throw new InvalidAccountException();
		System.out.println("enter pin");
		int pinn=in.nextInt();
		if(pinn!=pin)
			throw new InvalidPasswordException();
		System.out.println("enter amount");
		int amt=in.nextInt();
		if(amt>balance)
			throw new InsufficientFundsException();	
	} 

	catch(InvalidAccountException |InvalidPasswordException |InsufficientFundsException e){
		System.out.println(e.getMessage());
	}
}
	public static void main(String[] args) {
		
		throwingException();
			
	}

}
