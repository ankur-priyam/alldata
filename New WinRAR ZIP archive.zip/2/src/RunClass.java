
public class RunClass {

	public static void main(String[] args) {
		
		DayScholar obj=new DayScholar();
		Hosteller obj2=new Hosteller();
		double d=obj.payFee(2000);
		double d1=obj2.payFee(2000);
		System.out.println("amount payable for dayscholar = "+ d);
		System.out.println("amount payable for hosteller = "+ d1);

	}

}
