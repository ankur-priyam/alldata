import java.io.*;
public class Rectangle extends Shapes {

	
	void input() throws NumberFormatException, IOException {
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter length and breadth");
		length=Double.parseDouble(in.readLine());
		breadth=Double.parseDouble(in.readLine());
		}
	void area() {
		System.out.println("Area= " + (length*breadth));
		
	}
	public static void main(String args[])throws IOException
	{
	Rectangle obj=new Rectangle();
	obj.input();
	obj.area();
	
	}
}
