package ThreadsAssignment;

import java.io.FileInputStream;
import java.io.IOException;

public class FileHandling {

	static String f1;
	static String f2;
	public static void main(String[] args) {
		f1=args[0];
		f2=args[1];
		Threading n=new Threading();
		Thread t1=new Thread(n);
		Thread t2=new Thread(n);
		t1.setName("a");
		t2.setName("b");
		t1.start();
		t2.start();
		
		

	}

}
class Threading extends FileHandling implements Runnable
{

	@Override
	public synchronized void run() {
		
		String s;
		
		if(Thread.currentThread().getName().equalsIgnoreCase("a"))
			s=f1;
		else
			s=f2;
		try {
			FileInputStream in=new FileInputStream(s);
			int i;
			while((i=in.read())!=-1)
				System.out.print((char)i);
			System.out.println();
			in.close();
			Thread.sleep(3000);
		} catch (IOException | InterruptedException e) {
			
			e.printStackTrace();
		}
		
		
	}
	
}