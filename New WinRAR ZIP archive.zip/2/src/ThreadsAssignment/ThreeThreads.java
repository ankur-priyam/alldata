package ThreadsAssignment;

public class ThreeThreads {

	public static void main(String[] args) {
		NewThread n=new NewThread();
		Thread t1=new Thread(n);
		Thread t2=new Thread(n);
		Thread t3=new Thread(n);
		t1.setName("a");
		t2.setName("b");
		t3.setName("c");
		t1.setPriority(10);
		t2.setPriority(1);
		t3.setPriority(5);
		t1.start();
		t2.start();
		t3.start();
	}

}
class NewThread implements Runnable
{

	@Override
	public synchronized void run() {
		int i,j;
		if(Thread.currentThread().getName().equalsIgnoreCase("a"))
		{
			i=5;j=100;
		}
			else if(Thread.currentThread().getName().equalsIgnoreCase("b"))
			{
				i=10;j=200;}
			else
			{
				i=100;j=1000;
			}
		for(int k=i;k<=j;k+=i)
			System.out.print(k+" ");
		System.out.println();
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
	
}