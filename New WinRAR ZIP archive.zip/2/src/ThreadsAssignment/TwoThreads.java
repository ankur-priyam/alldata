package ThreadsAssignment;

public class TwoThreads {

	public static void main(String[] args) {
		

	}

}
class UsingThreads implements Runnable
{

	@Override
	public void run() {
		
		
	}
	
	
}