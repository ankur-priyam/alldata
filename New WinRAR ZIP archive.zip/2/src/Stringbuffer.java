import java.io.*;
public class Stringbuffer {
	public static void main(String args[])
	{
		
	StringBuffer n1=new StringBuffer();
	n1.append(args[0]);
	if(n1.equals(n1.reverse()))
		System.out.println("palindrome");
	else
		System.out.println("not a palindrome");
		
		
	}

}
