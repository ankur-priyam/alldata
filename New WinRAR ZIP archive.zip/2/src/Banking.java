
public class Banking {
private int emp_id;
private double salary;
private String emp_name;

public Banking() {
	emp_id=4455;
	emp_name="Astha";
}
public static void add(int a,int b)
{
	System.out.println("integer addn is " + (a+b));
	
	
}
public void add(String s,String s1)
{
	System.out.println("Astha is " + (s+s1));
	
	
}

public Banking(int emp_id, double salary, String emp_name) {
	this.emp_id = emp_id;
	this.salary = salary;
	this.emp_name = emp_name;
}

public int getEmp_id() {
	return emp_id;
}
public void setEmp_id(int emp_id) {
	this.emp_id = emp_id;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public String getEmp_name() {
	return emp_name;
}
public void setEmp_name(String emp_name) {
	this.emp_name = emp_name;
}
}
