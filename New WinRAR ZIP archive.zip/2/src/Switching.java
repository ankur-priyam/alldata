
public class Switching {

	public static void main(String[] args) {
		String color="blue";
		switch(color)
		{
		case "red":System.out.println("the selected colour is red");
		break;
		case "green":System.out.println("the selected colour is green");
		break;
		case "blue":System.out.println("the selected colour is blue");
		break;
		default:System.out.println("not applicable");
		
		
		}

	}

}
