
public interface Vehicle {
	void engines();
	void wheels();

}
