
public class Instance {

	public static void main(String[] args) {
		int a=10;
		double d=44.55;
		String s="ankur";
		if(Double.valueOf(d) instanceof Double)
			System.out.println("the given input is Double");
		else 
			System.out.println("not a string");

	}

}
