
public class Array {
	public static void main(String args[])
	{
		int arr[]=new int[10];
		double avg=0.0;
		//for insertion of values and finding max
		for(int i=0;i<10;i++)
		{
			arr[i]=i+5;
			avg=avg+arr[i];
		}
			avg=avg/(arr.length);
				System.out.println("The average value is " + avg);
				
				//for min and max
				
				int max=arr[0];
				int min=arr[0];
				for(int i=0;i<10;i++)
				{
					if(arr[i]>max)
						max=arr[i];
					if(arr[i]<min)
						min=arr[i];
				}
				System.out.println("Maximum value and minimum value are" + "   " + max +" and "+min);
				
		}
	}


