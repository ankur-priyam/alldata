package reservationSystem;

import java.util.Scanner;

public class Reservation {
	

	public static void main(String[] args) {
	BerthResevationApp app=new BerthResevationApp();
	Thread t1=new Thread(app);
	Thread t2=new Thread(app);
	Thread t3=new Thread(app);
	Thread t4=new Thread(app);
	t1.setName("a");
	t2.setName("b");
	t3.setName("c");
	t4.setName("d");
	t1.start();
	t2.start();
	t3.start();
	t4.start();
	}
}
class BerthResevationApp implements Runnable
{
int berth=20;
	@Override
	public synchronized void run() {
		System.out.println("welcome " + Thread.currentThread().getName());
		if(berth>0)
		{
			Scanner in=new Scanner(System.in);
			System.out.println("Available berths " + berth);
			System.out.println("enter no of berths");
			int no=in.nextInt();
			if(berth<no)
				System.out.println("not enough berths");
			else
			{
				System.out.println(no + "  berths allotted");
				berth-=no;
			}
		}
		else
			System.out.println("sorry no berths available");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		}
	}