package streams;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class UsingBufferedReader {
public static void main(String args[]) throws IOException
{
	BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
	System.out.println("enter name , code and salary");
	String name=in.readLine();
	int code=Integer.parseInt(in.readLine());
	double salary=Double.parseDouble(in.readLine());
	System.out.println(name+" "+code+" "+salary);
}
	
}
