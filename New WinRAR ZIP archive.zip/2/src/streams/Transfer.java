package streams;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Transfer {

	public static void main(String[] args) {
		try {
			FileOutputStream n=new FileOutputStream("C:\\ankur\\student.java");
			n.write(65);
			n.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		FileInputStream o;
		try {
			o = new FileInputStream("C:\\ankur\\student.java");
			int j;
			FileOutputStream n1=new FileOutputStream("C:\\ankur\\studentnew.java");
			while((j=o.read())!=-1)
			{
				
				n1.write(j);
			}
			o.close();n1.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
