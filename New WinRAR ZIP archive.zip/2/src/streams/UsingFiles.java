package streams;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class UsingFiles {
	public static void main(String args[]) {
		
		File f=new File("C:\\ankur");
		f.mkdir();
		try {
			FileOutputStream fos=new FileOutputStream("C:\\ankur\\new.txt");
			for(int i=97;i<123;i++)
				fos.write(i);
			fos.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		try {
			FileInputStream fis=new FileInputStream("C:\\ankur\\new.txt");
			int j;
			while((j=fis.read())!=-1)
				System.out.print((char)j);
			fis.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
