package Serializations;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class Deserialize {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
	FileInputStream fos=new FileInputStream("c:\\ank.txt");
ObjectInputStream ob=new ObjectInputStream(fos);
Object obj;
Employees emp;
while((obj=ob.readObject())!=null)
{
	emp=(Employees) obj;

	System.out.println(emp.getCode() + " " +emp.getName());
	}
ob.close();
}
}
