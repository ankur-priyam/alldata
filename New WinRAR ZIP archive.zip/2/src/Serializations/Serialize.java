package Serializations;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serialize {

	public static void main(String[] args) throws IOException {
		FileOutputStream out=new FileOutputStream("c:\\ank.txt");
		ObjectOutputStream oos=new ObjectOutputStream(out);
		Employees emp=new Employees();
		emp.setCode(256);
		emp.setName("ankur");
		Employees emp1= new Employees();
		emp1.setCode(257);
		emp1.setName("astha");
		oos.writeObject(emp1);
		oos.writeObject(emp);
		oos.close();
		System.out.println("done");
		

	}

}
