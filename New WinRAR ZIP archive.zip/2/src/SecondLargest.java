
public class SecondLargest {
	public static void main(String args[])
	{
		int a[]={77,88,1};
		//sorting in ascending order
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					int t=a[i];
					a[i]=a[j];
					a[j]=t;
					
				}
			}
			
		}
		System.out.println("the second largest no is " + a[a.length-2]);
		
		
	}

}
