
public class Bus implements Vehicle{

	public static void main(String[] args) {
		Bus obj=new Bus();
		obj.engines();
		obj.wheels();

	}

	@Override
	public void engines() {
		System.out.println("Bus has 1 engine");
		
	}

	@Override
	public void wheels() {
		System.out.println("Bus has 6 wheels");
		
	}

}
