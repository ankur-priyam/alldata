
public class StringManipulation {

	public static void main(String[] args) {
		String s1="Hyderabad";
		String s2="Telangana";
	System.out.println(s1.concat(s2));
	System.out.println(s1.length());
	System.out.println(s1.indexOf('b'));
	System.out.println(s1.replace("bad",""));
	System.out.println(s2.substring(0,5));
	System.out.println(s2.charAt(5));
	
	

	}

}
