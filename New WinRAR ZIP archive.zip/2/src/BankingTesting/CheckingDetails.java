package BankingTesting;

import java.util.Scanner;


public class CheckingDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner in=new Scanner(System.in);
long accountno;
int withdraw_amount;
int balance=5000;
try
{
System.out.println("enter account no");
accountno=in.nextLong();
	if (accountno==4465125)
	{
		
		System.out.println("enter amount to be withdrawn");
		withdraw_amount=in.nextInt();
			if(withdraw_amount>balance)
				throw new InsufficientFundsException();
		
	}
	else
		throw new InvalidAccountnoException();
}
	catch(InsufficientFundsException e)
	{
		System.out.println(e.getMessage());
	}
catch(InvalidAccountnoException f)
{
	System.out.println(f.getMessage());
}
finally
{
	in.close();
}
	}
	}

class InsufficientFundsException extends Exception
{
	public InsufficientFundsException()
	{
		super("not enough balance");
	}
}

class InvalidAccountnoException extends Exception
{
	public InvalidAccountnoException()
	{
		
	super("invalid acc no");
	}
}



