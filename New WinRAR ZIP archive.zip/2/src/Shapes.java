import java.io.IOException;


abstract public class Shapes {
	
	protected double length;
	protected double breadth;
	protected double radius;
	protected double side;
	abstract void input()throws IOException;
	abstract void area();
	

}
