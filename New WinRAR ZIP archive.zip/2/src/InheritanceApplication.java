
public class InheritanceApplication {
	
	
	protected int roll_no;
	protected double percent;
	protected String name;
	public InheritanceApplication() {
		roll_no=1;
		name="Ankur";
		percent=99.33;
	}
	public void display()
	{
		
		System.out.println(roll_no + " " + name + " " +percent);
	}

}
