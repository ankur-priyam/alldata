
public abstract class Students {

	protected int studId;
	protected String studName;
	protected double examFee;
	
	public Students() {
		examFee=5000;
	}

abstract void displayDetails();
abstract double payFee(double d);

}