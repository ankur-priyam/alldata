
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Square extends Shapes {

	public static void main(String[] args) throws IOException {
		Square obj=new Square();
		obj.input();
		obj.area();

	}

	@Override
	void input() throws IOException {
		BufferedReader in=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter side");
		side=Double.parseDouble(in.readLine());
		
	}

	@Override
	void area() {
		System.out.println("Area= " + (side*side));
	}

}

