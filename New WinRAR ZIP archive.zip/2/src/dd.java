
public class dd {

	public static void main(String[] args) {
		
		  int arr[]={1,2};
		  arr[2]=3/0;
		  System.out.println(arr[2]);         
		}
		


	}


