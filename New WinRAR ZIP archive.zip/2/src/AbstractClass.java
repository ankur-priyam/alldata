
public abstract class AbstractClass {
	
	abstract void display();
	int a=10;
	int b=20;
	public void output()
	{
		System.out.println(a+b);
	}

}
