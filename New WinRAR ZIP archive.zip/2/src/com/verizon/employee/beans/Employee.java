package com.verizon.employee.beans;

public class Employee {
private String ename;
private int ecode;
private double salary;
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public int getEcode() {
	return ecode;
}
public void setEcode(int ecode) {
	this.ecode = ecode;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}


}
