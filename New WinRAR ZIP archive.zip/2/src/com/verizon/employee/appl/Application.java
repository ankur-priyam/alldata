package com.verizon.employee.appl;

import java.util.List;

import com.verizon.employee.beans.Employee;
import com.verizon.employeeDAO.EmployeeDAO;

public class Application {

	public static void main(String[] args) {
		Employee emp=new Employee();
		EmployeeDAO emp2=new EmployeeDAO();
		//emp.setEcode(144);
		//emp2.Delete(emp);
		//System.out.println("done");
		emp.setEcode(150);
		List<Employee> elst=emp2.viewDataSpecific(emp);
		int c=0;
		for(Employee e:elst)
		{
				System.out.println(e.getEcode()+" "+e.getEname()+" "+e.getSalary());
				c=1;
		
		}
		if(c==0)
			System.out.println("not found");
	}
	

}
