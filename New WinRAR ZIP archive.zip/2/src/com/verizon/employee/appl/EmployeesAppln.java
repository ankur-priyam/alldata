package com.verizon.employee.appl;
import java.util.List;

import com.verizon.employee.beans.Employee;
import com.verizon.employee.beans.Employees;
import com.verizon.employeeDAO.EmployeesDAO;


public class EmployeesAppln {
		public static void main(String[] args) {
			Employees emp=new Employees();
			EmployeesDAO emp2=new EmployeesDAO();
			emp.setFIRST_NAME("ankur");
			emp.setFIRST_NAME("ankur");
			emp.setMIDDLE_NAME("s");
			emp.setLAST_NAME("priyam");
			emp.setDOJ(java.sql.Date.valueOf("2016-07-08"));
			emp.setDOB(java.sql.Date.valueOf("2016-07-08"));
			emp.setADDRESS("patna");
			emp.setCONTACT_NO(87562);
			emp.setDESIGNATION(1);
			emp.setROLE(2);
			emp2.addEmployee(emp);
			emp.setEMPLOYEE_ID(700);
			emp.setEMPLOYEE_ID(700);
			emp2.Delete(emp);
			List<Employees> elst=emp2.viewDataSpecificUsingFirst_Name(emp);
			int c=0;
			for(Employees e:elst)
			{
					System.out.println(e.getFIRST_NAME());
					c=1;
			
			}
			if(c==0)
				System.out.println("not found");
		
			
	}


	}


