
public interface Interface1 {

}
