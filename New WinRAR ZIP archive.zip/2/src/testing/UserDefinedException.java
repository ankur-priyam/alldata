package testing;

import java.util.Scanner;

public class UserDefinedException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int pin;
Scanner in=new Scanner(System.in);
System.out.println("enter pin");
pin=in.nextInt();
try{
if (pin==4544)
	System.out.println("correct pin");
else 
	throw new InvalidPasswordException();

	}
catch(InvalidPasswordException e)
{
	System.out.println(e.getMessage());
}
}
}
class InvalidPasswordException extends Exception
{

	public InvalidPasswordException()
	{
		super("wrong pin");}
}
