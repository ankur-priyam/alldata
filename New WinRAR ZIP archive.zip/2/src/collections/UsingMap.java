package collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class UsingMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<Integer, String> m = new HashMap<>();
		m.put(1, "Ankur");
		m.put(1, "verizon");
		m.put(3, "hyderabad");
		m.put(4, "gagsdf");
		System.out.println(m);
		System.out.println(m.get(3));
		Set s=m.entrySet();
		Iterator itr=s.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		

	}

}
