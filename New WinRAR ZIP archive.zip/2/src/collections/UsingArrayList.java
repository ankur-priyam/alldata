package collections;

import java.util.ArrayList;
import java.util.ListIterator;

public class UsingArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList itr=new ArrayList();
		itr.add("ankur");
		itr.add(546);
		itr.add(66.66);
		itr.remove("ankur");
		ListIterator item=itr.listIterator();
		System.out.println(itr.size());
		
		while(item.hasNext())
		{
	
			Object obj=item.next();
			if(obj instanceof Integer)
			System.out.println(obj);
			
			
		}

	}

}
