package collections;

import java.util.HashSet;

public class UsingHashset {
public static void main(String args[])
{
	HashSet itr=new HashSet();
	itr.add("ankur");
	itr.add(65);
	itr.add("ankur");
	System.out.println(itr);
	
}
}
