package collections;

import java.util.TreeSet;

public class UsingTreeSet {

	public static void main(String args[])
	{
		
		TreeSet itr=new TreeSet();
		itr.add("ankur");
		itr.add("verizon");
		itr.add("abc");
		//itr.add(45);
		System.out.println(itr);
		
	
	}
	
}

