package collections;
import java.util.ArrayList;


public class Usinglist2 {
	
	
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			ArrayList<String> itr=new ArrayList<>();
			itr.add("ankur");
			itr.add("546");
			itr.add("verizon");
			
			for(String s:itr)
				System.out.println(s);
		

	}

}
