
public class Transpose {

	public static void main(String[] args) {
		int a[][]=new int[10][10];
		//setting all elements to zero
		for(int i=0;i<10;i++)
		{
			for(int j=0;j<10;j++)
				a[i][j]=0;
		}
		//finding the transpose 
		int trans[][]=new int[10][10];
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				trans[i][j]=a[j][i];
		}
		//printing the values
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				System.out.print(a[i][j]);
				System.out.println();
	}
	}

}
