package test;

public class WirelessCustomer extends Customer {
	int router_charges=2000;

}
