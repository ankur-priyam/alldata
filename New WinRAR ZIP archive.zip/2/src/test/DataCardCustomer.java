package test;

public class DataCardCustomer extends Customer{

	int datacard_cost=1500;

	public int getDatacard_cost() {
		return datacard_cost;
	}

	public void setDatacard_cost(int datacard_cost) {
		this.datacard_cost = datacard_cost;
	}
}
