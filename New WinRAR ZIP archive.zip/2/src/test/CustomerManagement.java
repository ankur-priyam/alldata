package test;

import java.util.ArrayList;
import java.util.Scanner;

public class CustomerManagement {
	static DataCardCustomer obj=new DataCardCustomer();
	static WirelessCustomer obj2=new WirelessCustomer();
	static ArrayList<DataCardCustomer> dc=new ArrayList<DataCardCustomer>();
	static ArrayList<WirelessCustomer> wc=new ArrayList<WirelessCustomer>();
static void addCustomer()
{
	Scanner in=new Scanner(System.in);
	System.out.println("enter type of customer,enter custno , cust name , speed , Download limit , current usage");
	String s=in.next();
	
	if(s.equalsIgnoreCase("wireless"))
	{
		obj2.cust_no=in.nextInt();
	obj2.cust_name=in.next();
	obj2.speed=in.nextInt();
	obj2.down_limit=in.nextDouble();
	obj2.current_usage=in.nextDouble();
	obj2.balance_left=obj2.down_limit-obj2.current_usage;
	wc.add(obj2);
	}
	else
	{
		obj.cust_no=in.nextInt();
		obj.cust_name=in.next();
		obj.speed=in.nextInt();
		obj.down_limit=in.nextDouble();
		obj.current_usage=in.nextDouble();
		obj.balance_left=obj.down_limit-obj.current_usage;
		dc.add(obj);	
		
	}
}
	static void display()
	{
		for(WirelessCustomer wcc:wc)
			System.out.println(wcc.balance_left + wcc.cust_name );
		for(DataCardCustomer dcc:dc)
			System.out.println(dcc);
	}
	public static void main(String[] args) {
		
		addCustomer();
		display();
	}

}
