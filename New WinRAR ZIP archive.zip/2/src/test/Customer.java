package test;

public abstract class Customer {
	
	int cust_no;
	String cust_name;
	int speed;
	double down_limit;
	double current_usage;
	double balance_left;
	public int getCust_no() {
		return cust_no;
	}
	public void setCust_no(int cust_no) {
		this.cust_no = cust_no;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public double getDown_limit() {
		return down_limit;
	}
	public void setDown_limit(double down_limit) {
		this.down_limit = down_limit;
	}
	public double getCurrent_usage() {
		return current_usage;
	}
	public void setCurrent_usage(double current_usage) {
		this.current_usage = current_usage;
	}
	public double getBalance_left() {
		return balance_left;
	}
	public void setBalance_left(double balance_left) {
		this.balance_left = balance_left;
	}
	
}
