
public class UserInput {

	public static void main(String[] args) {
		int a=Integer.parseInt(args[0]);
		String s=args[1];
		System.out.println(s + a);
	}

}
