
public class Factorial {
static int fact(int n)
	{
		if(n==1)
			return 1;
		else
			return n*fact(n-1);
	}
public static void main(String args[])
{
	int num=5;
	if(num<=50&&num>=1)
	{
	int result=fact(num);
	System.out.println(result);
	}
	else
		System.out.println("value out of bounds");
}
}
