package multitasking;
class Numbers implements Runnable{
	public synchronized void run() {
		for(int i=0;i<5;i++)
		{
		System.out.print(i);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
}
public class UsingThreads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

Numbers num=new Numbers();
Thread t1=new Thread(num);
Thread t2=new Thread(num);
t1.start();
t2.start();
	
	
	}

}
