
public class ExtendingAbsClass extends AbstractClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExtendingAbsClass obj=new ExtendingAbsClass();
		obj.output();
	}

	@Override
	void display() {
		System.out.println("hello");
		
	}
	

}
