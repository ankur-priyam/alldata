package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UsingUpdate {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.OracleDriver");
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		Connection conn=DriverManager.getConnection(url, "scott", "tiger");
		System.out.println("connected");
		String dq="update ankur2 set salary=50000 where empname='ankur'";
		
		PreparedStatement pst=conn.prepareStatement(dq);
		pst.execute();
		System.out.println("updated");

	}

}
