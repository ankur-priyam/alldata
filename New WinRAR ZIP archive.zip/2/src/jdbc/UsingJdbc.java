package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class UsingJdbc {
	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
	Class.forName("oracle.jdbc.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:orcl";
	Connection conn=DriverManager.getConnection(url, "scott", "tiger");
	System.out.println("connected");
	Statement st=conn.createStatement();
	String q="create table ankur2(empcode number(4) primary key,empname varchar(20),salary number(7,2))";
	st.execute(q);
	System.out.println("table created");
	conn.close();
	
	
	
	
		
		
	}

}
