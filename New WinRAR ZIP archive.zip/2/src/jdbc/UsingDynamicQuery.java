package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class UsingDynamicQuery {
	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
		Class.forName("oracle.jdbc.OracleDriver");
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		Connection conn=DriverManager.getConnection(url, "scott", "tiger");
		System.out.println("connected");
		String dq="insert into ankur2 values(?,?,?)";
		PreparedStatement pst=conn.prepareStatement(dq);
		Scanner in =new Scanner(System.in);
		System.out.println("enter code name and salary");
		pst.setInt(1, in.nextInt());
		pst.setString(2, in.next());
		pst.setDouble(3, in.nextDouble());
		System.out.println("row created");
		in.close();
		pst.executeUpdate();
		
	}

}
