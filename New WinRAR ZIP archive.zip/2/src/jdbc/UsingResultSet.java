package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class UsingResultSet {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.OracleDriver");
		String url="jdbc:oracle:thin:@localhost:1521:orcl";
		Connection conn=DriverManager.getConnection(url, "scott", "tiger");
		System.out.println("connected");
		String sql="select * from ankur2";
		PreparedStatement pst=conn.prepareStatement(sql);
		ResultSet rs=pst.executeQuery();
		ResultSetMetaData md=rs.getMetaData();
		for(int i=1;i<=md.getColumnCount();i++)
			System.out.print(md.getColumnName(i)+ "   ");
		System.out.println("\n-----------------------");
		while(rs.next())
			System.out.println(rs.getInt(1)+"        "+rs.getString(2)+"        "+rs.getDouble(3));
			
		

	}

}
