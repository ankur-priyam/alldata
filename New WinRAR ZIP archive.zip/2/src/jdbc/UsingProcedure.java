package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

public class UsingProcedure {

	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
	Class.forName("oracle.jdbc.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:orcl";
	Connection conn=DriverManager.getConnection(url, "scott", "tiger");
	System.out.println("connected");
	CallableStatement cst=conn.prepareCall("call prcc(?,?,?)");
	cst.setInt(1, 139);
	cst.registerOutParameter(2,Types.VARCHAR);
	cst.registerOutParameter(3,Types.NUMERIC);
	cst.executeQuery();
	System.out.println(cst.getString(2));
	System.out.println(cst.getDouble(3));
	
	
}
}
