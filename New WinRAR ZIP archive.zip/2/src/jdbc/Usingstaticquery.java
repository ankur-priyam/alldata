package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Usingstaticquery {
	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
	Class.forName("oracle.jdbc.OracleDriver");
	String url="jdbc:oracle:thin:@localhost:1521:orcl";
	Connection conn=DriverManager.getConnection(url, "scott", "tiger");
	System.out.println("connected");
	Statement st=conn.createStatement();
	String insertq="insert into ankur2 values(142,'ankur',35000)";
	st.execute(insertq);
	System.out.println("row created");
	
	}
}
