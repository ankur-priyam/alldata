
public class MyClass {

	public static void main(String[] args) {
		
		Manager mng=new Manager();
		Clerk cle=new Clerk();
		mng.setEmp_id(100);
		mng.setName("Ashwin");
		mng.setSalary(130000);
		mng.setType("senior");
		cle.setEmp_id(101);
		cle.setName("Vishal");
		cle.setSalary(13000);
		cle.setSpeed(20);
		cle.setAccuracy(75);
		System.out.println("manager name " + mng.getName() + "\nemployee id " + mng.getEmp_id() + "\nsalary " + mng.getSalary() + "\ntype " + mng.getType());
		System.out.println("clerk name " + cle.getName() + "\nemployee id " + cle.getEmp_id() + "\nsalary " + cle.getSalary() + "\nspeed " + cle.getSpeed() +"\naccuracy " +cle.getAccuracy());
	}

}
