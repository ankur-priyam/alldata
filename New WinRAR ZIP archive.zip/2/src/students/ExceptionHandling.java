package students;

public class ExceptionHandling {

	public static void main(String[] args) throws ClassNotFoundException {
		int a=10;
		int b=1;
		int d[]={1,2,3,4,5};
		Class.forName("hii");
		try{
			
			int c=a/b;
			System.out.println(c);
			System.out.println(d[7]);
		}
		catch(ArithmeticException e)
		{
			
		e.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException f)
		{
			f.printStackTrace();
		}
finally{
	System.out.println("mandatory execution");
}
	}

}
