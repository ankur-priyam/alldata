package students;

public class Students {
	protected String name="ankur";
	protected int rollno=1;
	protected char group='A';

}
