package students;
import students.Library;
public class Exam {
	
	protected static int s1=100;
	protected static int s2=99;
	protected static int s3=99;
	
public static void main(String args[])
{
	Library obj =new Library();
	Students obj1=new Students();
			System.out.println(obj1.name);
	System.out.println("roll no -" + obj1.rollno);
	System.out.println("books due =" + obj.books_due);
	System.out.println("group code - " + obj1.group);
	System.out.println("total=" + (s1+s2+s3));
	
}
}

