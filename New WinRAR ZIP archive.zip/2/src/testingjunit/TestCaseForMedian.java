package testingjunit;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCaseForMedian {
	Median md=new Median();

	@Test
	public void testRotate() {
		assertEquals(md.rotate(md.a)[a.length-1],2 );
	}
	@Test
	public void testMedian() {
		assertEquals(md.median(md.b),5 );
	}
}
