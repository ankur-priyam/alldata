package testingjunit;

public class Median {
	
	static int a[]=new int[5];
	static int b[]=new int[a.length];
	
		public int[] rotate(int a[])
		{
		
		for(int i=0;i<=a.length-1;i++)
		{
			if(i==0)
				b[i]=a[a.length-1];
			else
				b[i]=a[i-1];
		}
		return b;
		}
		public static void main(String[] args) {
			
			for(int i=0;i<5;i++)
				a[i]=Integer.parseInt(args[i]);
			Median m=new Median();
			int b[]=m.rotate(a);
		}
		public double median(int b[])
		{
		double media;
		{
		if(b.length % 2==0)
		{
			int med=(b.length/2)-1;
			media=(b[med]+b[med+1])/2;
		}
		
			
		else
			media=b[b.length/2];
		return media;
	}
}
}
