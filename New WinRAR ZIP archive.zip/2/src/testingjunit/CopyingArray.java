package testingjunit;

import static org.junit.Assert.*;

import org.junit.Test;

public class CopyingArray {
CopyArray ab=new CopyArray();
	@Test
	public void testCopy() {
		assertArrayEquals(ab.a, ab.copy(ab.a));
	}

}
