package testingjunit;

public class CopyArray 
{
	int a[]={1,2,3,4,5};
	int b[]=new int[5];;
	public int[] copy(int a[])
	{
		for(int i=0;i<a.length;i++)
			b[i]=a[i];
		return b;
	}
}



