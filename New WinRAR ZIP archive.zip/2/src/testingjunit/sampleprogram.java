package testingjunit;

public class sampleprogram {
	public int add(int x,int y)
	{
		int z=x+y;
		return z;
	}

}
