
public class UsingClasses {

	public static void main(String[] args) {
		Banking bank=new Banking();
		Banking new2=new Banking(7626,500000.00,"ankur");
		int x=Banking.add(4,5);
		System.out.println(bank.add("9", "pointer"));
	
		System.out.println("Employee no " + bank.getEmp_id() + "is" + bank.getEmp_name());
		System.out.println(new2.getEmp_id() + new2.getEmp_name() + new2.getSalary());		
	}

}
