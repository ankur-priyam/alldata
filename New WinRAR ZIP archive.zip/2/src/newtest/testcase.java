package newtest;

import static org.junit.Assert.*;

import org.junit.Test;

import testingjunit.sampleprogram;

public class testcase {
	sampleprogram ab=new sampleprogram();
	

	@Test
	public void testAddPositive() {
		assertEquals(8, ab.add(3, 5));
		
	}
	@Test
	public void testAddNegative() {
		assertNotEquals(8, ab.add(3, 5));
		
	}

}
