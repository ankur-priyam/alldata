package newtest;

import static org.junit.Assert.*;

import org.junit.Test;

import testingjunit.GreatestTest;

public class GreatestTestTestCase {
GreatestTest ab = new GreatestTest();
	@Test
	public void testPositive() {
		assertEquals(8, ab.test(1, 2, 8));
		
	}
	@Test
	public void testNegative1() {
		assertNotEquals(1, ab.test(1, 2, 8));
		
}
	@Test
	public void testNegative2() {
		assertNotEquals(2, ab.test(1, 2, 8));
}
}