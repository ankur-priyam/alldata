
public class StudentMarks {

	public static void main(String[] args) {
		int rno=1;
		int s1Marks=30;
		int s2Marks=45;
		int s3Marks=100;
		String name="Astha";
		float total=s1Marks+s2Marks+s3Marks;
		float avg=total/3;
		System.out.println("total marks and Average Marks for "+ name + " roll no "+rno +"  are respectively");
		System.out.println(total+"  ");
		System.out.println(avg+"  ");
		if(s1Marks>=50&&s2Marks>=50&&s3Marks>=50)
			System.out.println("pass");
		else
			System.out.println("fail\nab kar maze");
		
	}

}
