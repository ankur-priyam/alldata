
public class Matrices {

	public static void main(String[] args) {
		int a[][]={{1,2,3},{4,5,6},{7,8,9}};
		int b[][]={{10,11,12},{13,14,15},{16,17,18}};
		int c[][]=new int[3][3];
		for(int i=0;i<3;i++)
		{
			
				int r=0,r1=0;
			while(r<3)
			{
				while(r1<3)
			{
				
				c[i][r]=c[i][r]+a[r1][r]*b[r1][r];
				r1++;
			}
				r++;
		}
		}
			
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
				System.out.print(c[i][j]);
			System.out.println();
		}

	}

}
