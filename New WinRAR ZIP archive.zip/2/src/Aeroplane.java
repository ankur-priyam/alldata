
public class Aeroplane implements Vehicle{

	public static void main(String[] args) {
		Aeroplane obj=new Aeroplane();
		obj.engines();
		obj.wheels();

	}

	@Override
	public void engines() {
		System.out.println("Aeroplane has 4 engine");
		
	}

	@Override
	public void wheels() {
		System.out.println("Aeroplane has 10 wheels");
		
	}

}
