import java.util.Scanner;


public class BankingSystem {
	static int balance=1000;
	static void deposite()
	{
		System.out.println("enter amount");
		Scanner in = new Scanner(System.in);
		int amt=in.nextInt();
		balance+=amt;
	}
	static void balance()
	{
		System.out.println("Total balance in account is" + balance);
	
	}
	static void withdrawal()
	{
		System.out.println("enter amount");
		Scanner in = new Scanner(System.in);
		int amt=in.nextInt();
		try{
		if(balance>amt)
		balance-=amt;
		else
			throw new InsufficientFundsException();
		}
		catch(InsufficientFundsException e)
		{
		System.out.println(e.getMessage());
		}
		}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		while(true)
		{
		System.out.println("1.Deposite\n2.Withdrawal\n3.Balance\nEnter your choice\n");
		int choice=in.nextInt();
		switch(choice)
		{
		case 1:deposite();break;
		case 2:withdrawal();break;
		case 3:balance();break;
		default:System.out.println("wrong entry");
		}
		System.out.println("press any integer to continue -1 to exit");
		int ch=in.nextInt();
		if(ch==-1)
			break;
		}
}
	}



	class InsufficientFundsException extends Exception
	{
		public InsufficientFundsException()
		{
			super("not enough balance");
		}
	}
