
public class DayScholar extends Students{
	protected double transportFee;

	public DayScholar() {
		transportFee=10000;
	}

	@Override
	void displayDetails() {
		System.out.println("student id " + studId + "\n" + studName);
		
	}

	@Override
	double payFee(double d) {
		double total=examFee+transportFee;
		return (total-d);
	}
	
	
	

}
