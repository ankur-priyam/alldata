
public class Hosteller extends Students {
protected double hostelFee;

public Hosteller() {
	hostelFee=13000;
}

@Override
void displayDetails() {
	// TODO Auto-generated method stub
	
}

@Override
double payFee(double d) {
	double total=examFee+hostelFee;
	return (total-d);

}

}
