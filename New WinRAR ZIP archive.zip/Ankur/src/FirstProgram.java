import java.io.*;
public class FirstProgram {

	public static void main(String[] args)throws IOException {
	
BufferedReader into=new BufferedReader(new InputStreamReader(System.in));
System.out.println("enter no");
int num=Integer.parseInt(into.readLine());
//for area and circumference
double area=Math.PI*num*num;
double circumference=2*Math.PI*num;
System.out.println("the area and circumference are" + area + "and" +circumference);
//length of diagonal
double diag=Math.sqrt(num*num + num*num);
System.out.println("the length of diagonal is " + diag);
//surface area and volume
double srfarea=4*Math.PI*num*num;
double volume=(4/3)*Math.PI*num*num*num;
System.out.println("the volume and surface area of sphere are" + volume +"and" + srfarea);

	}

}
