package springmvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {
	@RequestMapping("/Loginvalidate.htm")
	public ModelAndView Cont(@ModelAttribute("login")Login log){
		ModelAndView mod= new ModelAndView();
		mod.addObject("data",log);
		if(log.getUsername().equals("admin")&&log.getPassword().equals("admin"))
			mod.setViewName("Admin");
		else
			mod.setViewName("User");
		return mod;
			
	}

}
