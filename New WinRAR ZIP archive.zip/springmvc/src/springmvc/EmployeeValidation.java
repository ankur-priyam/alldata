package springmvc;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
@Component
public class EmployeeValidation implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		return Employee.class.isAssignableFrom(arg0);
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		Employee emp=(Employee) arg0;
		ValidationUtils.rejectIfEmpty(arg1, "ename", "name.null");
		if(emp.getEmpcode()<=0)
			arg1.rejectValue("empcode", "code.null");
		if(emp.getSalary()<=0)
		arg1.rejectValue("salary", "sal.null");
	}
	

}
