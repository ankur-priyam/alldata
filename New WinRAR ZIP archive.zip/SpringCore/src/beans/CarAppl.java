package beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarAppl {

	public static void main(String[] args) {
		ApplicationContext cnt=new ClassPathXmlApplicationContext("beans/Context.xml");
		Car c=(Car) cnt.getBean("car");
		c.moving();
		
		
	}

}
