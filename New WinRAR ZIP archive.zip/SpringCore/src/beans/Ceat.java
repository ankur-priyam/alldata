package beans;

public class Ceat implements Wheel {

	@Override
	public void rotate() {
		System.out.println("Ceat wheels are rotating....");
		
	}

}
