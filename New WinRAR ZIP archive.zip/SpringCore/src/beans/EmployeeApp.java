package beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeApp {

	public static void main(String[] args) {
		ApplicationContext cnt=new ClassPathXmlApplicationContext("beans/Context.xml");
		Employee em=(Employee) cnt.getBean("emp");
		System.out.println("code=" + em.getCode() + "\nName=" + em.getName() +"\nAddress=" + em.getAddress().getCity());
		
	}

}
