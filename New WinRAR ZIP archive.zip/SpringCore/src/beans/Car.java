package beans;

public class Car {
	Wheel wheel;
	
	public Wheel getWheel() {
		return wheel;
	}
	public void setWheel(Wheel wheel) {
		this.wheel = wheel;
	}
	public void moving()
	{
		wheel.rotate();
		System.out.println("Car is moving....");
	}
}
