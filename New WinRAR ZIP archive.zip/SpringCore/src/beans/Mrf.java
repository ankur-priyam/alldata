package beans;

public class Mrf implements Wheel {

	@Override
	public void rotate() {
		System.out.println("MRF wheels are rotating...");
		
	}

}
