package beans;

public interface Wheel {
void rotate();
}
