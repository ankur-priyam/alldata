package annotations;

public interface Wheel {
void rotate();
}
