package annotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CarAppl {

	public static void main(String[] args) {
		ApplicationContext cnt=new ClassPathXmlApplicationContext("annotations/Annotation.xml");
		Car c=(Car) cnt.getBean("car");
		c.moving();
		
		
	}

}
