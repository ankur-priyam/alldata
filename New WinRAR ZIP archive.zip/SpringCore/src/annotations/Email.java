package annotations;

import org.springframework.stereotype.Component;

@Component
public class Email implements MessageService{

	@Override
	public void sendMessage(String receivername, String message) {
		System.out.println("message sent to " + receivername);
		
	}

}
