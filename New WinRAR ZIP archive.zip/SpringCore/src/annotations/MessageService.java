package annotations;

public interface MessageService {
void sendMessage(String receivername,String message);
}
