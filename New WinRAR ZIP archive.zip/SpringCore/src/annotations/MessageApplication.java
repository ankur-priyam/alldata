package annotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MessageApplication {

	public static void main(String[] args) {
		ApplicationContext ctx=new ClassPathXmlApplicationContext("annotations/Annotation.xml");
		MyMessageSender mms=(MyMessageSender) ctx.getBean("myMessageSender");
		mms.SendMessage("ankur", "hii");

	}

}
