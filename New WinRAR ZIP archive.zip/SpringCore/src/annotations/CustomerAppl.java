package annotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CustomerAppl {
	public static void main(String args[])
	{
		ApplicationContext ctx=new ClassPathXmlApplicationContext("annotations/Annotation.xml");
		Customer cst=(Customer) ctx.getBean("customer");
		cst.setCode(114);
		cst.setName("ankur");
		Address adr=(Address) ctx.getBean("address");
		adr.setCity("hyderabad");
		System.out.println(cst.getCode());
		System.out.println(cst.getAddress().getCity());
	
				
				
		
	}

}
