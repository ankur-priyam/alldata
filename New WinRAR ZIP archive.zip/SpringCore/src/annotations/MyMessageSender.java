package annotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class MyMessageSender {
	@Autowired
	@Qualifier("twitter")
	MessageService ms;

	public MessageService getMs() {
		return ms;
	}

	public void setMs(MessageService ms) {
		this.ms = ms;
	}
	public void SendMessage(String receivername,String message){
		ms.sendMessage(receivername, message);
	}
}
