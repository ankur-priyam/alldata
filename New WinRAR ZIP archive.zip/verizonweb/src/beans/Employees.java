package beans;

import java.sql.Date;

import javax.xml.crypto.Data;

public class Employees {
	private int EMPLOYEE_ID;
	private String FIRST_NAME;
	private String MIDDLE_NAME;
	private String LAST_NAME;
	Date DOJ;
	Date DOB;
	private String ADDRESS;
	private long CONTACT_NO;
	private int DESIGNATION;
	private int ROLE;
	public int getEMPLOYEE_ID() {
		return EMPLOYEE_ID;
	}
	public void setEMPLOYEE_ID(int eMPLOYEE_ID) {
		EMPLOYEE_ID = eMPLOYEE_ID;
	}
	public String getFIRST_NAME() {
		return FIRST_NAME;
	}
	public void setFIRST_NAME(String fIRST_NAME) {
		FIRST_NAME = fIRST_NAME;
	}
	public String getMIDDLE_NAME() {
		return MIDDLE_NAME;
	}
	public void setMIDDLE_NAME(String mIDDLE_NAME) {
		MIDDLE_NAME = mIDDLE_NAME;
	}
	public String getLAST_NAME() {
		return LAST_NAME;
	}
	public void setLAST_NAME(String lAST_NAME) {
		LAST_NAME = lAST_NAME;
	}
	public Date getDOJ() {
		return DOJ;
	}
	public void setDOJ(Date dOJ) {
		DOJ = dOJ;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getADDRESS() {
		return ADDRESS;
	}
	public void setADDRESS(String aDDRESS) {
		ADDRESS = aDDRESS;
	}
	public long getCONTACT_NO() {
		return CONTACT_NO;
	}
	public void setCONTACT_NO(long cONTACT_NO) {
		CONTACT_NO = cONTACT_NO;
	}
	public int getDESIGNATION() {
		return DESIGNATION;
	}
	public void setDESIGNATION(int dESIGNATION) {
		DESIGNATION = dESIGNATION;
	}
	public int getROLE() {
		return ROLE;
	}
	public void setROLE(int rOLE) {
		ROLE = rOLE;
	}

}
