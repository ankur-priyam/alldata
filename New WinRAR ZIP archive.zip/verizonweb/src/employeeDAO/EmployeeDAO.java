package employeeDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beans.Employee;

public class EmployeeDAO {
	private Connection conn;
	private PreparedStatement pst;
	private ResultSet rs;
	List<Employee> employees=new ArrayList<>();
	public void getDBConnection()
	{
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:orcl";
			conn=DriverManager.getConnection(url, "scott", "tiger");
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	public void close()
	{
		try {
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	public void addEmployee(Employee emp)
	{
		try {
			getDBConnection();
			pst=conn.prepareStatement("insert into employee values(?,?,?)");
			pst.setInt(1,emp.getEcode());
			pst.setString(2, emp.getEname());
			pst.setDouble(3, emp.getSalary());
			pst.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	finally
		{
			close();
		}
	}
	
	public void Update(Employee emp)
	{
		getDBConnection();
		try {
			pst=conn.prepareStatement("update employee  set salary=? where ecode=?");
			pst.setDouble(1,emp.getSalary());
			pst.setInt(2, emp.getEcode());
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close();
		}
	}
	public void Delete(Employee emp)
	{
		
		try {
			getDBConnection();
			pst=conn.prepareStatement("delete from employee where ecode=?");
			//pst.setDouble(1,emp.getSalary());
			pst.setInt(1, emp.getEcode());
			//pst.executeUpdate();
		} catch (SQLException e) {
								
			e.printStackTrace();
		}
		
finally
{
	close();
}
}
public List<Employee> viewData()
{
	getDBConnection();
	try {
		pst=conn.prepareStatement("select * from employee");
		rs=pst.executeQuery();
		while(rs.next())
		{
			Employee emp = new Employee();
			emp.setEcode(rs.getInt(1));
			emp.setEname(rs.getString(2));
			emp.setSalary(rs.getDouble(3));
			employees.add(emp);
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
finally
{
	close();
}
	return employees;
}
public List<Employee> viewDataSpecific(Employee emp1)
{
	getDBConnection();
	try {
		pst=conn.prepareStatement("select * from employee");
		rs=pst.executeQuery();
		while(rs.next())
		{
			Employee emp = new Employee();
			emp.setEcode(rs.getInt(1));
			emp.setEname(rs.getString(2));
			emp.setSalary(rs.getDouble(3));
			if(emp.getEcode()==emp1.getEcode())
			employees.add(emp);
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
finally
{
	close();
}
	return employees;
}
}

