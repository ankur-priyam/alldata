package employeeDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.verizon.employee.beans.Employee;
import com.verizon.employee.beans.Employees;

public class EmployeesDAO {
	private Connection conn;
	private PreparedStatement pst;
	private ResultSet rs;
	List<Employees> employ=new ArrayList<>();
	public void getDBConnection()
	{
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:orcl";
			conn=DriverManager.getConnection(url, "scott", "tiger");
		} catch (ClassNotFoundException | SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	public void close()
	{
		try {
			conn.close();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	public void addEmployee(Employees emp)
	{
		try {
			getDBConnection();
			pst=conn.prepareStatement("insert into employees values(seq8.nextVal,?,?,?,?,?,?,?,?,?)");
			pst.setString(1,emp.getFIRST_NAME());
			pst.setString(2, emp.getMIDDLE_NAME());
			pst.setString(3, emp.getLAST_NAME());
			pst.setDate(4,emp.getDOJ());
			pst.setDate(5, emp.getDOB());
			pst.setString(6, emp.getADDRESS());
			pst.setLong(7,emp.getCONTACT_NO());
			pst.setInt(8, emp.getDESIGNATION());
			pst.setInt(9, emp.getROLE());
			pst.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	finally
		{
			close();
		}
	}
	
	public void Update(Employees emp)
	{
		getDBConnection();
		try {
			pst=conn.prepareStatement("update employees  set role=? where employee_id=?");
			pst.setInt(1,emp.getROLE());
			pst.setInt(2, emp.getEMPLOYEE_ID());
			pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			close();
		}
	}
	public void Delete(Employees emp)
	{
		
		try {
			getDBConnection();
			pst=conn.prepareStatement("delete from employees where employee_id=?");
			pst.setInt(1,emp.getEMPLOYEE_ID());
			pst.executeUpdate();
		} catch (SQLException e) {
								
			e.printStackTrace();
		}
		
finally
{
	close();
}
}

public List<Employees> viewDataSpecificUsingID(Employees emp1)
{
	getDBConnection();
	try {
		pst=conn.prepareStatement("select * from employees");
		rs=pst.executeQuery();
		while(rs.next())
		{
			Employees emp = new Employees();
			emp.setEMPLOYEE_ID(rs.getInt(1));
			if(emp.getEMPLOYEE_ID()==emp1.getEMPLOYEE_ID())
			{
			emp.setFIRST_NAME(rs.getString(2));
			emp.setMIDDLE_NAME(rs.getString(3));
			emp.setLAST_NAME(rs.getString(4));
			emp.setDOJ(rs.getDate(5));
			emp.setDOB(rs.getDate(6));
			emp.setADDRESS(rs.getString(7));
			emp.setCONTACT_NO(rs.getLong(8));
			emp.setDESIGNATION(rs.getInt(9));
			emp.setROLE(rs.getInt(10));
			employ.add(emp);
			}
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
finally
{
	close();
}
	return employ;
}
public List<Employees> viewDataSpecificUsingFirst_Name(Employees emp1)
{
	getDBConnection();
	try {
		pst=conn.prepareStatement("select * from employees");
		rs=pst.executeQuery();
		while(rs.next())
		{
			Employees emp = new Employees();
			emp.setFIRST_NAME(rs.getString(2));
			if(emp.getFIRST_NAME().equalsIgnoreCase(emp1.getFIRST_NAME()))
			{
			emp.setEMPLOYEE_ID(rs.getInt(1));
			emp.setMIDDLE_NAME(rs.getString(3));
			emp.setLAST_NAME(rs.getString(4));
			emp.setDOJ(rs.getDate(5));
			emp.setDOB(rs.getDate(6));
			emp.setADDRESS(rs.getString(7));
			emp.setCONTACT_NO(rs.getLong(8));
			emp.setDESIGNATION(rs.getInt(9));
			emp.setROLE(rs.getInt(10));
			employ.add(emp);
			}
			
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
finally
{
	close();
}
	return employ;
}
}