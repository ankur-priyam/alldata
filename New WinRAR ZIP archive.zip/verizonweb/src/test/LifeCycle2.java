package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LifeCycle2
 */
public class LifeCycle2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int count=55;

	/**
	 * @see Servlet#init(ServletConfig)
	 */


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.println("<h2>" + count++ +"</h2>");
		ServletContext context=getServletContext();
		out.println("url is=" + context.getInitParameter("db_url") + "<br>");
		ServletConfig config=getServletConfig();
		out.println("city=" + config.getInitParameter("city"));
	
	
	}

}
