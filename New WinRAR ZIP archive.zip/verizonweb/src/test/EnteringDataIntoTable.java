package test;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import employeeDAO.EmployeeDAO;
import beans.Employee;

/**
 * Servlet implementation class EnteringDataIntoTable
 */
public class EnteringDataIntoTable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter b=response.getWriter();
		Employee emp=new Employee();
		emp.setEcode(Integer.parseInt(request.getParameter("code")));
		emp.setEname(request.getParameter("name"));
		emp.setSalary(Double.parseDouble(request.getParameter("salary")));
		EmployeeDAO emp2=new EmployeeDAO();
		emp2.addEmployee(emp);
		b.println("done");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
