package test;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import linking.ValidateUser;
import beans.Employee;
import employeeDAO.EmployeeDAO;

/**
 * Servlet implementation class ViewList
 */
public class ViewList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		ValidateUser n=new ValidateUser();
		HttpSession nn=request.getSession();
		EmployeeDAO dao=new EmployeeDAO();
		List<Employee> lst=dao.viewData();
		out.println("<html><body>");
		out.println("<table border=2>");
		out.println("<tr><th>EMPL CODE<th>EMPL NAME<th>EMPL SALARY</th></tr>");
		for(Employee e:lst)
		{
			out.println("<tr>");
			out.println("<td>" + e.getEcode());
		out.println("<td>" + e.getEname());
		out.println("<td>" +e.getSalary());
		out.println("</tr>");
	}
		out.println("</table></body></html>");
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		EmployeeDAO dao=new EmployeeDAO();
		List<Employee> lst=dao.viewData();
		out.println("<html><body>");
		out.println("<table border=2>");
		out.println("<tr><th>EMPL CODE<th>EMPL NAME<th>EMPL SALARY</th></tr>");
		for(Employee e:lst)
		{
			out.println("<tr>");
			out.println("<td>" + e.getEcode());
		out.println("<td>" + e.getEname());
		out.println("<td>" +e.getSalary());
		out.println("</tr>");
	}
		out.println("</table></body></html>");
	}
}
