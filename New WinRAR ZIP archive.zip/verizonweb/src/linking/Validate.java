package linking;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Validate
 */
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String s=request.getParameter("user_id");
		RequestDispatcher rd;
		if(s.equalsIgnoreCase("admin"))
				{
			response.sendRedirect("http://mail.google.com");
			//rd=request.getRequestDispatcher("Admin");
			//rd.forward(request, response);
				}
		else{
			response.sendRedirect("/NewProject/src/eventmanager/Event.java");
			//rd.forward(request, response);
			
		}
	}

}
