package linking;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

/**
 * Servlet implementation class ValidateUser
 */
public class ValidateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String s=request.getParameter("user_id");
		String s1=request.getParameter("pass");
		HttpSession sess=request.getSession();
		RequestDispatcher rd;
		if(s.equalsIgnoreCase("admin") && s1.equals("admin"))
				{
			
			sess.setAttribute("id", 10);
			rd=request.getRequestDispatcher("Admin.html");
			rd.forward(request, response);
				}
		else if(s.equalsIgnoreCase("") || s1.equals(""))
		{
			out.println("Enter all fields");
		rd=request.getRequestDispatcher("login.html");
		rd.include(request, response);
	}
		else{
			rd=request.getRequestDispatcher("User.html");
			rd.include(request, response);
		}
	}
}
